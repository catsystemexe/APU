# Scripts

Sem mohou přijít skripty (např. v Pythonu), které:
- poskládají více modulů do jednoho knowledge souboru,
- zkontrolují duplicity nebo konflikty,
- připraví finální prompt pro GPT model.
