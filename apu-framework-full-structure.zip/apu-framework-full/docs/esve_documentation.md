# Dokumentace ESVE (Skeleton)

Sem lze vložit text detailní dokumentace k ESVE (např. pro grant nebo technické partnery).
