# Architektura APU frameworku – přehled

Stručný popis složek, jejich rolí a vztahů.
