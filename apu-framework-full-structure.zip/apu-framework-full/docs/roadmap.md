# Roadmap

Představa dalšího vývoje frameworku (verze 1, 2, 3…).
