# Koncept APU pro ZUŠ

Shrnutí cílů, přínosů a praktického využití pro základní umělecké školy.
