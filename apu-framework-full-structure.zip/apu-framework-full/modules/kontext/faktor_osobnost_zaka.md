# Modul: Kontext – osobnost žáka

- různé temperamenty,
- citlivost, introverze, extroverze,
- vztah k výkonu a chybě.
