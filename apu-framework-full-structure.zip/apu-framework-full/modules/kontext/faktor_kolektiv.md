# Modul: Kontext – kolektiv

- role skupinové dynamiky,
- riziko šikany nebo vyloučení,
- pozitivní vliv soudržné skupiny.
