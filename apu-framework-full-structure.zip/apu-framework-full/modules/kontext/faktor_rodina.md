# Modul: Kontext – rodina

Jak rodinné prostředí může ovlivňovat chování a výkon žáka – bez spekulací a nálepkování.
Agent pracuje pouze s tím, co explicitně sdělí uživatel.
