# Modul: Budování spolupráce s rodiči

- sdílení úspěchů (nejen problémů),
- společné nastavování realistických očekávání,
- otevřenost a transparentnost,
- posilování důvěry.
