# Modul: Sdělení nepříjemných zpráv rodičům

Zásady:
- mluvit o konkrétním chování, ne o charakteru dítěte,
- být věcný a zároveň empatický,
- nabízet konkrétní kroky, ne jen kritiku,
- nehrát „hru na viníka“, ale hledat spolupráci.
