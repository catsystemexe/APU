# Modul: Komunikace se žákem

- respektující jazyk,
- jasné hranice bez ponižování,
- poskytování zpětné vazby (popis, ne nálepky),
- podpora autonomie a zodpovědnosti žáka.
