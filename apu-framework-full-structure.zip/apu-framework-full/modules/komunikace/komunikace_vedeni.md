# Modul: Komunikace s vedením školy

- jak formulovat žádost nebo popis problému,
- jak podat návrh na změnu,
- jak dokumentovat opakované situace (pro budoucí řešení).
