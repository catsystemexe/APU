# Modul: Komunikace s rodičem

- jak sdělovat nepříjemné informace,
- jak vyvážit ocenění a kritiku,
- jak popsat konkrétní chování místo „charakterových soudů“,
- jak nastavovat společná očekávání a hranice.
