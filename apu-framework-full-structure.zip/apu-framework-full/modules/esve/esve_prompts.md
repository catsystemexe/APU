# ESVE – Prompt šablony (Skeleton)

Sem přijdou konkrétní promptové šablony pro interní použití agenta při práci se zdroji.
