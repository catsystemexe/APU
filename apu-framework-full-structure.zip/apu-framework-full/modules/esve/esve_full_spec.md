# ESVE – Plná specifikace (Skeleton)

Zde může být vložen kompletní text detailní specifikace ESVE modulu.
Slouží jako hlavní technická a metodická dokumentace validační vrstvy.
