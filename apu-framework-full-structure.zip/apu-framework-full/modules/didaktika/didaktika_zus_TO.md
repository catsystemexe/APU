# Modul: Didaktika ZUŠ – Taneční obor

Skeleton.

Témata:
- bezpečnost pohybu,
- práce s tělem a vnímáním vlastního těla,
- skupinová koordinace, práce v prostoru,
- příprava na vystoupení a choreografie.
