# Modul: Didaktika ZUŠ – LDO

Skeleton.

Témata:
- improvizace, práce s hlasem,
- dramatická cvičení, hry,
- skupinová dynamika na jevišti,
- práce se studem a trémou.
