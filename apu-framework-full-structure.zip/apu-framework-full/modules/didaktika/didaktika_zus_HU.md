# Modul: Didaktika ZUŠ – Hudební obor

Skeleton pro budoucí detailnější obsah.

Témata:
- struktura individuální hodiny hry na nástroj,
- práce s domácím cvičením (zadávání, kontrola, motivace),
- budování repertoáru (technické vs. výrazové skladby),
- příprava na vystoupení a přehrávky.
