# Modul: Didaktika – Core

Obecné didaktické principy použitelné napříč typy škol.

- strukturování hodiny (začátek – střed – závěr),
- aktivizace žáků (otázky, dialog, úkoly),
- kontrola porozumění (formativní hodnocení),
- přizpůsobení tempa a obtížnosti.

Specifické oborové aplikace jsou v souborech `didaktika_zus_*.md`.
