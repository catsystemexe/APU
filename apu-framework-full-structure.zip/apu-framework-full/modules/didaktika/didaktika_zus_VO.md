# Modul: Didaktika ZUŠ – Výtvarný obor

Skeleton.

Témata:
- zadávání témat (volná tvorba vs. strukturované úkoly),
- práce s kritikou a sebehodnocením,
- podpora tvořivosti bez přetížení,
- práce s chybou jako s příležitostí.
