# Modul: Úzkost a panické reakce

Skeleton.

Témata:
- jak reagovat na žáka v akutní úzkosti,
- co rozhodně nedělat (bagatelizace, zesměšnění),
- kdy doporučit odbornou pomoc.
