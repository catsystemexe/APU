# Modul: Agresivita a konflikty

Skeleton.

Témata:
- deeskalace konfliktu,
- bezpečné zásahy učitele,
- práce s vlastními emocemi,
- kdy zapojit vedení školy nebo rodiče.
