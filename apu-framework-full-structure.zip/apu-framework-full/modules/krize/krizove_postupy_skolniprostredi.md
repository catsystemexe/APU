# Modul: Krizové postupy ve školním prostředí

Skeleton.

- základní krizové scénáře,
- doporučené reakce v roli učitele,
- spolupráce s vedením a odborníky.
