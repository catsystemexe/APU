# Modul: Signály sebepoškozování

Skeleton.

Témata:
- jaké signály mohou vyvolat podezření,
- jak o tom mluvit s žákem,
- kdy a jak zapojit rodiče, PPP, OSPOD,
- jak chránit žáka i sebe v rámci kompetencí učitele.
