# Modul: Prevence vyhoření

- rozpoznání varovných signálů u sebe,
- práce s hranicemi,
- hledání podpory (kolegové, supervize).
