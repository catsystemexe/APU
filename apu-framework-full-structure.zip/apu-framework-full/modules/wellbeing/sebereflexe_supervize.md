# Modul: Sebereflexe a supervize

- jak reflektovat své reakce,
- kdy hledat supervizní prostor,
- jak využít APU jako „zrcadlo“ vlastní praxe.
