# Modul: Psychohygiena učitele

- krátké techniky na zklidnění během dne,
- jednoduché rituály po náročné hodině,
- jak o sebe pečovat dlouhodobě.
