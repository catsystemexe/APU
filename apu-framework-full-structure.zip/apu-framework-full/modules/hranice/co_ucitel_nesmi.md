# Modul: Co učitel nesmí

Skeleton pro právní a etické hranice.
