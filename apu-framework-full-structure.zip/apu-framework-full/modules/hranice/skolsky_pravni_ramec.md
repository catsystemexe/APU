# Modul: Školský právní rámec (CZ)

Skeleton – bude doplněn odkazy na školský zákon, vyhlášky a metodiky.
