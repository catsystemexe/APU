# Modul: Kdy předat případ OSPOD / PPP / dalším odborníkům

Skeleton – základní signály a doporučení, kdy už situace přesahuje roli učitele.
