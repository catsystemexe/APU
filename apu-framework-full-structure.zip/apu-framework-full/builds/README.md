# Builds

Do tohoto adresáře patří výsledné "kompilované" knowledge prompty pro konkrétní agenty.

Příklady:
- `apu_zus_v1_knowledge.md` – první verze APU pro ZUŠ postavená nad core + ZUŠ profily + vybrané moduly.
