# Testovací scénáře – ZUŠ

Sem můžeš vkládat modelové situace (use-cases), na kterých budeš APU testovat.
Např.:
- "12letá žákyně, tréma před koncertem…"
- "konflikt ve skupinové výuce…"
