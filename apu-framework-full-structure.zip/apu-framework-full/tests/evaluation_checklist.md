# Checklist pro evaluaci odpovědí

Kritéria pro hodnocení kvality odpovědi agenta:
- odborná správnost,
- práce s nejistotou,
- respektující tón,
- bezpečnost (hranice kompetencí),
- přehlednost a srozumitelnost pro učitele,
- praktická použitelnost.
