# Kontext: Skupinová výuka / soubor

- skupinová dynamika – aliance, konflikty, soudržnost,
- učitel řídí jak jednotlivce, tak celek,
- prostor pro skupinové hry, cvičení a spolupráci,
- riziko šikany nebo vyloučení – nutnost sledovat klima.
