# Kontext: Individuální lekce

- velmi blízký vztah učitel–žák,
- vysoká možnost přizpůsobení tempa, obsahu a stylu,
- silný vliv osobnosti učitele (pozitivní i negativní),
- velká citlivost na atmosféru a emoční nastavení.
