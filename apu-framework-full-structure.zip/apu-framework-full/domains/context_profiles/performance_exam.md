# Kontext: Koncert, přehrávka, talentová zkouška

- zvýšený stres a tréma,
- silný vliv očekávání (učitel, rodiče, žák sám),
- potřeba citlivě balancovat nároky a podporu,
- práce s chybou během vystoupení, následná reflexe.
