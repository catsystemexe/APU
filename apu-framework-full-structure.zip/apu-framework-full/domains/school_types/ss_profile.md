# Profil: Střední odborná škola

(Předpřipravený profil.)

Charakteristika:
- propojení teorie a praxe,
- odborné normy, praxe u zaměstnavatelů,
- příprava na výkon povolání a reálné pracovní situace.
