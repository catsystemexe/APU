# Profil: ZŠ 1. stupeň

(Předpřipravený profil pro budoucí rozšíření.)

Charakteristika:
- mladší školní věk (cca 6–10 let),
- důraz na hravost, pohyb, imaginaci,
- rozvoj základních gramotností (čtení, psaní, počítání),
- silná role rodičů a rodinného prostředí.

Zatím skeleton – detailní obsah bude doplněn později.
