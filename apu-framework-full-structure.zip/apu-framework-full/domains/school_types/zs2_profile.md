# Profil: ZŠ 2. stupeň

(Předpřipravený profil.)

Charakteristika:
- puberta, silnější emoční výkyvy, hledání identity,
- větší vliv vrstevníků a skupinové dynamiky,
- rostoucí nároky na samostatnost a zodpovědnost.

Zatím skeleton – detailní obsah bude doplněn později.
