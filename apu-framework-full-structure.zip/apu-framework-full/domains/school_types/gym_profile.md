# Profil: Gymnázium

(Předpřipravený profil.)

Charakteristika:
- důraz na kritické myšlení, práci se zdroji, abstraktní myšlení,
- příprava na VŠ, testy, přijímačky,
- větší kapacita pro abstraktní diskuzi o metodách a teoriích.

Skeleton – obsah se doplní v další fázi projektu.
